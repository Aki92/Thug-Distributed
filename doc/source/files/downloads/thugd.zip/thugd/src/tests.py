from ThugD.thug_instances import thug
from nose.tools import eq_
import json


# Options to pass
options = {'--w':10, '-h':1}

# JSON format of options
opts = json.dumps(options)

#Running single task & getting result back
def test_task():
    res = thug.apply_async(args=('https://www.google.co.in/', opts, )).get()
    print eq_(res, "Check Help Options locally(no remote help is available)")
