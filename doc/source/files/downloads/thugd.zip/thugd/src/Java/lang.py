
from .System import System

class lang:
    def __init__(self):
        self.System = System()

