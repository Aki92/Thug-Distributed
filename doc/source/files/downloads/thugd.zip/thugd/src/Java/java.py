
from .lang import lang

class java:
    def __init__(self):
        self.lang = lang()
