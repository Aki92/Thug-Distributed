#!/usr/bin/env python
#
# thug.py
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA  02111-1307  USA

import sys
import os
import logging

from ThugAPI import *
from Plugins.ThugPlugins import *

log = logging.getLogger("Thug")
log.setLevel(logging.WARN)


class Thug(ThugAPI):
    def __init__(self, url):
        # args(url) not used in ThugAPI code so just passed URL
        ThugAPI.__init__(self, url)

    def analyze(self, options):
        p = getattr(self, 'run_remote', None)
        
        for opt in options:
            if opt in ('-h', '--help'):
                return 'Check Help Options locally(no remote help is available'
            if opt in ('-V', '--version'):
                return self.thug_version

        for opt in options:
            if opt in ('-u', '--useragent', ):
                self.set_useragent(options[opt])
            if opt in ('-e', '--events'):
                self.set_events(options[opt])
            if opt in ('-w', '--delay'):
                self.set_delay(options[opt])
            if opt in ('-r', '--referer', ):
                self.set_referer(options[opt])
            if opt in ('-p', '--proxy', ):
                self.set_proxy(options[opt])
            if opt in ('-l', '--local', ):
                p = getattr(self, 'run_local')
            if opt in ('-x', '--local-nofetch', ):
                p = getattr(self, 'run_local')
                self.set_no_fetch()
            if opt in ('-v', '--verbose', ):
                self.set_verbose()
            if opt in ('-d', '--debug', ):
                self.set_debug()
            if opt in ('-m', '--no-cache'):
                self.set_no_cache()
            if opt in ('-a', '--ast-debug', ):
                self.set_ast_debug()
            if opt in ('-A', '--adobepdf', ):
                self.set_acropdf_pdf(options[opt])
            if opt in ('-P', '--no-adobepdf', ):
                self.disable_acropdf()
            if opt in ('-S', '--shockwave', ):
                self.set_shockwave_flash(options[opt])
            if opt in ('-R', '--no-shockwave', ):
                self.disable_shockwave_flash()
            if opt in ('-J', '--javaplugin', ):
                self.set_javaplugin(options[opt])
            if opt in ('-K', '--no-javaplugin', ):
                self.disable_javaplugin()
            if opt in ('-t', '--threshold', ):
                self.set_threshold(options[opt])
            if opt in ('-E', '--extensive', ):
                self.set_extensive()
            if opt in ('-T', '--timeout', ):
                self.set_timeout(options[opt])
            if opt in ('-Q', '--urlclassifier'):
                for classifier in options[opt].split(','):
                    self.add_urlclassifier(os.path.abspath(classifier))
            if opt in ('-W', '--jsclassifier'):
                for classifier in options[opt].split(','):
                    self.add_jsclassifier(os.path.abspath(classifier))

        self.log_init(self.args)

        for option in options:
            if opt in ('-n', '--logdir'):
                self.set_log_dir(options[opt])
            if opt in ('-o', '--output', ):
                self.set_log_output(options[opt])
            if opt in ('-q', '--quiet', ):
                self.set_log_quiet()

        if p:
            ThugPlugins(PRE_ANALYSIS_PLUGINS, self)()
            p(self.args)
            ThugPlugins(POST_ANALYSIS_PLUGINS, self)()

        self.log_event()
        return log
