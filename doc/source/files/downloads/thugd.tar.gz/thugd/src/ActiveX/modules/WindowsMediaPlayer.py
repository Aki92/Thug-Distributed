
import logging
log = logging.getLogger("Thug")

def Play(self):
    log.warning("[WindowsMediaPlayer] Play")
