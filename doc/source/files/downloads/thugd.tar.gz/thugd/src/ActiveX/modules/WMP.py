
import logging
log = logging.getLogger("Thug")

def openPlayer(self, arg):
    log.warning(arg)
