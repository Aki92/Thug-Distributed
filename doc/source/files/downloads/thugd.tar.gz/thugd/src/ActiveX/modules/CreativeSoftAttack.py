
import logging
log = logging.getLogger("Thug")

def Setcachefolder(self, val):
    log.ThugLogging.log_exploit_event(self._window.url,
                                      "CreativeSoft ActiveX",
                                      "Overflow in cachefolder property")

