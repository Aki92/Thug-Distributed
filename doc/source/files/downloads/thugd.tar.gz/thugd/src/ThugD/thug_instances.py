from __future__ import absolute_import
from ThugD.main_server import thugd
import time
import sys
import os

# Adding path to sys path variable 
# os.getcwd => path of parent directory where call_thug resides
sys.path.append(os.getcwd())
import call_thug

# Making Thug Function to be called as task
@thugd.task
def thug(url, options):
    res = call_thug.Thug(url)
    log = res.analyze(options)
    return log    

'''
    if not os.getenv('THUG_PROFILE', None):
        res = call_thug.Thug(url)
        log = res.analyze(**options)
    else:
        import cProfile
        import pstats
        cProfile.run('Thug(sys.argv[1:])()', 'countprof')
        p = pstats.Stats('countprof')
        res = p.print_stats()
'''
