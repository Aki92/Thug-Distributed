	def find_ip(self):
		# Finding both IP4 & IP6 addresses
		network_interfaces = nf.interfaces()
		# Keeping only connections other than ethernet, wireless, localhost
		network_interfaces = [n for n in network_interfaces if(not
							  n.startswith('lo') and not n.startswith('eth') and
							  not n.startswith('wlan'))
							  ]
		ip4 = ''
		ip6 = ''
		for network in network_interfaces:
			# Finding IP4 address
			try:
				ip4 = nf.ifaddresses(network)[nf.AF_INET][0]['addr']
			except:
				pass

			# Finding IP6 address
			try:
				ip6 = nf.ifaddresses(network)[nf.AF_INET6][0]['addr']
			except:
				pass

		self.ip4 = ip4
		self.ip6 = ip6
		return (self.ip4, self.ip6)
