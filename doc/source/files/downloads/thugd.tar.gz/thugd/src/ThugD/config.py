# Site using to find IP address
site  = 'http://wtfismyip.com/json'